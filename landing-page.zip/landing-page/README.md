# Landing Page

Modern landing page with Tailwind, Framer Motion, and Shadcn/UI.